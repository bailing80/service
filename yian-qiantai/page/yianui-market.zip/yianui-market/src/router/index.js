import Vue from 'vue'
import Router from 'vue-router'
import Cookies from "js-cookie"
import Register from '@/views/Register'
import NotFound from '@/views/Error/404'
import Home from '@/views/Home'
import MainPage from '@/views/MainPage'
import Login from '@/views/Login'
import Cardhospital from '@/views/Sys/Cardhospital'
import Preview from '@/views/Sys/Preview'
import PrivacyExplain from '@/views/Sys/PrivacyExplain'
import EndPage from '@/views/EndPage'
import Submit from '@/views/Submit'
import VG70caiye from '@/views/VG70caiye'
import caiye510S from '@/views/caiye510S'
import caiye590P from '@/views/caiye590P'



import api from '@/http/api'
import store from '@/store'
import { getIFramePath, getIFrameUrl } from '@/utils/iframe'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/register',
      name: '注册',
      component: Register
    },
    {
      path: '/caiye510S',
      name: '彩页',
      component: caiye510S
    },
    {
      path: '/vg70caiye',
      name: '彩页',
      component: VG70caiye
    },
    {
      path: '/caiye590P',
      name: '彩页',
      component: caiye590P
    },
    {
     path: '/',
     name: '登录',
    component: Login
  },

    {
      path: '/mainpage',
      name: '主页面',
      component: MainPage
    },
    {
      path: '/endpage',
      name: '最终页面',
      component: EndPage
    },
    {
      path: '/submit',
      name: '提交',
      component: Submit
    },
    {
      path: '/cardhospital',
      name: '医院用户',
      component: Cardhospital
    },
    {
      path: '/privacyexplain',
      name: '隐私说明',
      component: PrivacyExplain
    },
  

    {
      path: '/404',
      name: 'notFound',
      component: NotFound
    }
  ]
})

// router.beforeEach((to, from, next) => {
//   // 登录界面登录成功之后，会把用户信息保存在会话
//   // 存在时间为会话生命周期，页面关闭即失效。
//   let token = Cookies.get('token')
//   let userName = sessionStorage.getItem('user')

//   if (to.path === '/login') {
//     // 如果是访问登录界面，如果用户会话信息存在，代表已登录过，跳转到主页
//     if(token) {
//          next({ path: '/' })    
//     } else {
         
//          next()    
        
//     }
//   } else {
//     if (!token) {
//          next({ path: '/login' })
//     } else {
//         next()    
//         //next()
//     }
//   }
// })




export default router
