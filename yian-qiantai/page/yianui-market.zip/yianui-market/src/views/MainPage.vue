<template>
  <el-form :model="loginForm" ref="loginForm" label-position="left" label-width="359px">
    <el-row style="right:150px">
      <el-col :span="27">
        <el-menu
          default-active="2"
          class="el-menu-vertical-demo"
          background-color="#F4F4F6"
          text-color="#555555"
          active-text-color="#ffffff"
          style="height:700px;width:374px;"
        >
        






          <el-tabs v-model="activeName" @tab-click="handleClick" style="margin-left:70px;">

            <el-tab-pane label="Brochure" name="first">

              <router-link to="vg70caiye">
                <div>
                <el-button style="width:240px;height:150px;margin-top:0px;margin-right:144px">
                  <img
                    style="width:80px;height:130px;position:absolute;top:10px;left:10px;"
                    src="@/assets/VG70.png"
                  />
                
                  <p style="margin-top:10px;margin-left:80px;font-size:11px;">VG70 English Brochure</p>
                </el-button>
                </div>
              </router-link>
              <router-link to="caiye510S">
                <div>
                <el-button style="width:240px;height:150px;margin-top:10px;margin-right:144px">
                  <img
                    style="width:80px;height:130px;position:absolute;top:170px;left:10px;"
                    src="@/assets/510S.png"
                  />
                  <p style="margin-top:25px;margin-left:80px;font-size:11px;">Shangrila510S English</p>
                  <p style="margin-top:10px;margin-left:80px;font-size:11px;">Brochure</p>
                </el-button>
                </div>
              </router-link>
              <router-link to="caiye590P">
                                 <div>

                <el-button style="width:240px;height:150px;margin-top:20px;margin-right:144px">
                  <img
                    style="width:80px;height:130px;position:absolute;top:340px;left:10px;"
                    src="@/assets/590P.png"
                  />
                <p style="margin-top:10px;margin-left:90px;font-size:11px;">Shangrila590P</p>
                <p style="margin-top:10px;margin-left:90px;font-size:11px;"> Brochure</p>
                  <!-- <el-form-item
                    header-align="center"
                    prop="account"
                    label="Shangrila590P Brochure"
                    label-width="200px"
                    text-align="center"
                    style="margin-top:40px;margin-left:130px;"
                  ></el-form-item> -->
                </el-button>
                                 </div>
              </router-link>
              
              <el-form-item
                header-align="center"
                prop="account"
                label-width="60px"
                text-align="center"
                style="width:385px;margin-top:160px;"
              ></el-form-item>
            </el-tab-pane>
            <el-tab-pane label="Video" name="second">
              <div  style="background: #ffffff;width:240px;height:150px;position:absolute;top:0px;left:0px;">
                   <p style="margin-top:40px;margin-left:110px;font-size:11px;">VG70 Installation Guidance</p>
                     <img
                style="width:80px;height:130px;position:absolute;top:10px;left:10px;"
                src="@/assets/VG70.png"
              />
            
                <el-button
                  type="primary"
                  onclick="location.href='https://youtu.be/iuru0I_PuH4';"
                  style="position:absolute;top:90px;right:30px;"
                >Play</el-button>
              <!-- </el-form-item> -->
              </div>
                <div  style="background: #ffffff;width:240px;height:150px; margin-top:170px;left:10px;">
              <img
                style="width:80px;height:130px;position:absolute;top:180px;left:10px;"
                src="@/assets/510S.png"
              />
              <p style="position:absolute;margin-top:30px;margin-left:110px;font-size:11px;">Shangrila510S English</p>
              <p style="position:absolute;margin-top:50px;margin-left:150px;font-size:11px;">Brochure</p>
              <el-button
                type="primary"
                onclick="location.href='https://youtu.be/s8Kx3GZp1sQ';"
                style="position:absolute;top:260px;right:90px;"
              >Play</el-button>
              </div>
                 <!-- <img
                style="width:200px;height:150px;position:absolute;top:470px;right:200px;"
                src="@/assets/590P.png"
              /> -->
                 <div  style="background: #ffffff;width:240px;height:150px;margin-top:20px;left:10px;">

                  <img
                style="width:80px;height:130px;position:absolute;top:350px;left:10px;"
                src="@/assets/590P.png"
              />
              <p style="position:absolute;top:370px;left:105px;font-size:11px;">Shangrila590P Brochure</p>
              <el-button
                type="primary"
                onclick="location.href='https://youtu.be/iuru0I_PuH4';"
                style="position:absolute;top:430px;right:85px;"
              >Play</el-button>
              </div>
            

             
            

              <!-- 
                 <el-form-item header-align="center" prop="account"  label-width="30px" text-align="center"  style="margin-top:90px;">
                 <el-link type="info" href="https://youtu.be/iuru0I_PuH4" >VG70 Installation Guidance</el-link>
                 </el-form-item>
                 <el-form-item header-align="center" prop="account"  label-width="30px" text-align="center"  style="margin-top:90px;">
                 <el-link type="info" href="https://youtu.be/s8Kx3GZp1sQ" >Shangrila510S Installation Guidance</el-link>    
                 </el-form-item>   
                 <el-form-item header-align="center" prop="account"  label-width="30px" text-align="center"  style="margin-top:90px;">        
                 <el-link type="info" href="https://youtu.be/iuru0I_PuH4" >Shangrila510S Installation Guidance</el-link>
                 </el-form-item> 
                 <el-form-item header-align="center" prop="account"  label-width="60px" text-align="center"  style="width:385px;margin-top:160px;">          
              </el-form-item>-->
              <!-- <div class="player-container"><video-player class="vjs-custom-skin" :options="playerOptions">00000000</video-player> </div> -->
            </el-tab-pane>
            
            <el-tab-pane label="Message" name="third">
             
              <el-input
                type="textarea"
                :rows="10"
                placeholder="Leave your question here:"
                v-model="loginForm.remarks"
                style="margin-top:30px;width:250px;right:25px;"
              ></el-input>
              <el-button
                type="info"
                style="width:60%;height:38px;margin-right:50px;margin-top:100px;background: #854FC1;border-radius: 19px;"
                @click.native.prevent="submitForm"
              >提交</el-button>
            </el-tab-pane>
         
          </el-tabs>
           
        </el-menu>
        <el-form-item></el-form-item>
      </el-col>
    </el-row>
  </el-form>
</template>

<script>
import KtButton from "@/views/Core/KtButton";
import { format } from "@/utils/datetime";
import XLSX from "xlsx";
import { mapState } from "vuex";
import Cookies from "js-cookie";
// import 'video.js/dist/video-js.css'
// import 'vue-video-player/src/custom-theme.css'
// import 'videojs-contrib-hls.js/src/videojs.hlsjs'
//import Time from 'time_check_jiangji'
import {
  provinceAndCityData,
  CodeToText,
  TextToCode
} from "element-china-area-data";

export default {
  data() {
    return {
      activeName: "second",
      msg: "",

      loginForm: {
        account: "admin",
        password: "admin",
        remarks: "",
        playerOptions: {
          playbackRates: [0.7, 1.0, 1.5, 2.0], //播放速度
          autoplay: false, //如果true,浏览器准备好时开始回放。
          controls: true, //控制条
          preload: "auto", //视频预加载
          muted: false, //默认情况下将会消除任何音频。
          loop: false, //导致视频一结束就重新开始。
          language: "zh-CN",
          aspectRatio: "16:9", // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
          fluid: true, // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
          sources: [
            {
              type: "video/mp4",
              src: "https://v.youku.com/v_show/id_XNDU4NTA5NTM0OA==.html" //你所放置的视频的地址，最好是放在服务器上
            }
          ],
          poster: "http://39.106.117.192:8080/static/indexImg.png", //你的封面地址（覆盖在视频上面的图片）
          width: document.documentElement.clientWidth,
          notSupportedMessage: "此视频暂无法播放，请稍后再试" //允许覆盖Video.js无法播放媒体源时显示的默认信息。
        }
      }
      //加
    };
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },

    submitForm() {
      if (this.loginForm.remarks) {
        let userInfo = {
          account: this.loginForm.account,
          password: this.loginForm.password
        };
        this.$api.login.login(userInfo).then(res => {
          if (res.msg != null) {
            this.$message({
              message: res.msg,
              type: "error"
            });
          } else {
            Cookies.set("token", res.data.token); // 放置token到Cookie
          }
          let userInfo = { remarks: this.loginForm.remarks };
          this.$api.englishuser.remarksave(userInfo).then(res => {
            if (res.msg != null) {
              this.$message({
                message: res.msg,
                type: "error"
              });
            }
            this.$message({ message: "Tip: successfully added" });
            //this.$refs['loginForm'].resetFields()
            this.loginForm.remarks = "";
          });
        });
      } else {
        this.$message({ message: "Content cannot be empty！", type: "error" });
        return false;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.login-container {
  -webkit-border-radius: 5px;
  border-radius: 5px;
  width: 1850px;
  -moz-border-radius: 5px;
  background-clip: padding-box;
  margin: 0px 0px 0px 0px;
  position: absolute;
  padding: 35px 35px 120px 35px;
  background: #fff;
  border: 1px solid #eaeaea;
  box-shadow: 0 0 25px #cac6c6;
  .title {
    margin: 30px auto 30px auto;
    text-align: center;
    color: #505458;
  }
  .remember {
    margin: 0px 0px 35px 0px;
  }
}
.bailing {
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #666666;
  line-height: 14px;
}
</style>