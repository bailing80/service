<template>
    <el-form label-position="left" class="demo-ruleForm login-container">
       <el-form-item>
          <img style="width:131px;height:25px;margin-top:50px;"  src="@/assets/logo.png" />   
       </el-form-item>
         
       <el-form-item header-align="center" prop="email" label="Email" label-width="190px" text-align="center"  style="margin-top:45px;margin-left:60px;">
          <el-input style="width:200px;right:80px;" type="text" header-align="left" label-width="25px" placeholder="Please enter Email"  v-model="loginForm.email"></el-input>
       </el-form-item>
       <el-form-item header-align="center" prop="password" label="Password" text-align="center" label-width="190px" style="margin-top:45px;margin-left:55px;">
          <el-input style="width:200px;right:75px;" type="password" header-align="left" label-width="15px"  placeholder="Please enter Password"  v-model="loginForm.password" ></el-input>
       </el-form-item>
       <el-form-item header-align="center" prop="passwordagain" label="Re-enter password" label-width="190px" style="margin-top:45px;margin-left:40px;">
          <el-input style="width:200px;right:60px;" v-model="loginForm.passwordagain"    placeholder="Please Re-enter password"  type="password"></el-input>
      </el-form-item>
       <el-form-item header-align="center" prop="phone" label="Phone" label-width="190px" style="margin-top:45px;margin-left:60px;">
           <el-input v-model="loginForm.phone" auto-complete="off" style="width:200px;right:80px;"   placeholder="Please enter phone" type="text"></el-input>
       </el-form-item>
        <div>
        <div class="bbb">
        <el-checkbox  v-model="checked">I agree</el-checkbox>
       </div>
       <div >
      <el-link style="right:-10px;margin-top:20px;" type="primary" href="#/privacyexplain" target="_blank">By creating an account, you agree to  Conditions of Use and Privacy Notice.</el-link>
      </div>
      </div>
       <el-form-item>         
       <el-button type="info" style="width:60%;height:38px;right:50px;margin-top:35px;margin-left:20px;background: #854FC1;border-radius: 19px;" @click.native.prevent="zhuce">Sign up</el-button>
       </el-form-item>
       <div style="width:300px;height:45px;" ></div>
       </el-form>
</template>

 
<script>
import { mapState } from 'vuex'
import Cookies from "js-cookie"
import ThemePicker from "@/components/ThemePicker"
import LangSelector from "@/components/LangSelector"

export default {
//  name: 'HelloWorld',
  data () {
    return {
      msg: '',
      checked: false,
      //加
       loginForm: {
        account: '',
        password: '',
      
      }, 
      //加
    }
  },
  methods:{
  
    //加
      zhuce() { 
        if (!this.checked) {
         this.$message({ message: "Please agree to  Conditions of Use and Privacy Notice.！", type: "error" });
        return false;
       }
       if(this.loginForm.password  != this.loginForm.passwordagain){
          this.$message({ message: "Two password entries are inconsistent！", type: "error" });
          return false;
       }else{
         let letemil=this.loginForm.email
         let letphone=this.loginForm.phone
         let userInfo = {email:this.loginForm.email, password:this.loginForm.password,phone:this.loginForm.phone}
         console.log("11111111"+this.loginForm.email+"\n11:"+this.loginForm.password+"\n 0222:"+this.loginForm.phone);
      this.$api.englishuser.save(userInfo).then((res) => {  
     

          if(res.msg != null) {
            this.$message({
              message: res.msg,
              type: 'error'
            })
          } else {
  
            Cookies.set('token', res.data.token) // 放置token到Cookie
            console.log(res.data.token+"00000000");
            sessionStorage.setItem('user', userInfo.account) // 保存用户到本地会话
        
         
            this.$router.push(
        
              //  this.$router.push({path:'/queryresults',query:{name:this.loginForm.serialnumber}})  // 登录成功，跳转到主页
                         {
              
                            path:'/submit',
                            query:{letemail:this.loginForm.email,letphone:this.loginForm.phone},
                          
                            })                
                         }
          

        }).catch((res) => {
          this.$message({
          message: res.message,
          type: 'error'
          })
        });}
    },
    //加
   
  }
}
</script>

<style lang="scss" scoped>
.div-inline{ 
  float:left;
  } 
.login-container {
  -webkit-border-radius: 5px;
  border-radius: 5px;
  -moz-border-radius: 5px;
  background-clip: padding-box;
  position: relative; 
  right:170px;
  width: 393px;
  height:100%;
  padding: 0px 0px 0px 0px;
  background: #fff;
  border: 1px solid #eaeaea;
  box-shadow: 0 0 0px #cac6c6;
}

.aaa{
float:left;
}
.bbb{
margin-left:160px;
margin-top:30px;

float:left;
}
.ccc{
float:left;
}
</style>
