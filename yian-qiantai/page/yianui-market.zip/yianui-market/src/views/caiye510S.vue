<template>
  <el-form :model="loginForm" ref="loginForm" label-position="left" label-width="359px" >
    <el-row style="right:144px">
      <el-col :span="27">
        <el-menu  default-active="2"  class="el-menu-vertical-demo"  background-color="#F4F4F6"  text-color="#555555"  active-text-color="#ffffff">
          <router-link to="/mainpage">
         <img style="width:20px;height:20px;position:absolute; top:18px;left:40px;" src="@/assets/icon_back@2x.png" />
        </router-link>
          <el-form-item header-align="center" prop="account" label="Shangrila510S English Brochure" label-width="200px" text-align="center"  style="margin-top:10px;margin-left:80px;">
          </el-form-item>
               <img style="width:320px;height:550px;margin-top:5px;left:10px;" src="@/assets/510-1.png"/>
               <img style="width:320px;height:550px;margin-top:5px;left:10px;" src="@/assets/510-2.png"/>
               <img style="width:320px;height:550px;margin-top:5px;left:10px;" src="@/assets/510-3.png"/>
               <img style="width:320px;height:550px;margin-top:5px;left:10px;" src="@/assets/510-4.png"/>
         </el-menu>
        <el-form-item>
      </el-form-item>
      </el-col>
    </el-row>
  </el-form>
</template>

<script>
import KtButton from "@/views/Core/KtButton"
import { format } from "@/utils/datetime"
import XLSX from 'xlsx'
import { mapState } from "vuex"
import Cookies from "js-cookie"
//import Time from 'time_check_jiangji'
import { provinceAndCityData,CodeToText, TextToCode} from "element-china-area-data"
    
export default {

     data () {
     return {
        activeName: 'second',
        msg: '',
     
         loginForm: {
             textarea:'',
      }, 
      //加
    }
  },
  methods: {
          handleClick(tab, event)
           {
             console.log(tab, event);
          }
        }
      }
</script>

<style lang="scss" scoped>

.login-container {
  -webkit-border-radius: 5px;
  border-radius: 5px;
  width: 1850px;
  -moz-border-radius: 5px;
  background-clip: padding-box;
  margin: 0px 0px 0px 0px;
  position: absolute;
  padding: 35px 35px 120px 35px;
  background: #fff;
  border: 1px solid #eaeaea;
  box-shadow: 0 0 25px #cac6c6;
  .title {
    margin: 30px auto 30px auto;
    text-align: center;
    color: #505458;
  }
  .remember {
    margin: 0px 0px 35px 0px;
  }
}
.bailing{
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #666666;
  line-height: 14px;
}
</style>