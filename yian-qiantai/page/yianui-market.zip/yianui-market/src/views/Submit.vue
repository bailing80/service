<template>
    <el-form label-position="left" class="demo-ruleForm login-container">
       <el-form-item>
          <img style="width:131px;height:25px;margin-top:50px;;margin-left:20px;"  src="@/assets/logo.png" />   
       </el-form-item>
         <p style="font-size:20px;margin-left:20px;margin-top:20px;">Personal information</p>
       <el-form-item header-align="center" prop="name" label="Your name" label-width="190px" text-align="center"  style="margin-top:50px;margin-left:60px;">
           <el-input style="width:180px;right:70px;" type="text"  header-align="left" label-width="25px" placeholder="Please enter your name"  v-model="loginForm.name" ></el-input>
       </el-form-item>
  <el-form-item header-align="center" prop="diccode" label="Your country" label-width="190px" style="margin-top:50px;margin-left:60px;">
         <el-input v-model="loginForm.diccode" auto-complete="off" style="width:180px;right:70px;"   placeholder="Please enter your country" maxlength="11" type="text"></el-input>
      </el-form-item>
      <el-form-item header-align="center" prop="identificationnumber" label="Serial number" label-width="190px" style="margin-top:50px;margin-left:60px;">
         <el-input v-model="loginForm.identificationnumber" auto-complete="off" style="width:180px;right:70px;"   placeholder="Please enter serial number" maxlength="11" type="text"></el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="info" style="width:60%;height:38px;margin-top:70px;margin-left:35px;background: #854FC1;border-radius: 19px;"  @click.native.prevent="submit">Submit</el-button>
      </el-form-item>
               <div style="width:300px;height:53px;" ></div>
        <el-form-item>
      </el-form-item>
  </el-form>
</template>
 
<script>
import { mapState } from 'vuex'
import Cookies from "js-cookie"
import ThemePicker from "@/components/ThemePicker"
import LangSelector from "@/components/LangSelector"

export default {
  //name: 'HelloWorld',
  data () {
    return {
      msg: '',
      checked: false,
      //加
       loginForm: {
         name: '',
         hospital: '',
         identificationnumber: '',
         hospital: [{
			   value: '男',
				label: '男'
				},{
				value: '女',
				label: '女'
				}],
      }, 
      //加
    }
  },
  created()
  {
    
    this.getParams();
  
  },
  methods:{
      getParams:function ()
      {
          let emialparams=this.$route.query.letemail;
          let phoneparams=this.$route.query.letphone;
         
      },
      submit() { 
      let userInfo = {name:this.loginForm.name, diccode:this.loginForm.diccode,identificationnumber:this.loginForm.identificationnumber,phone:this.$route.query.letphone,email:this.$route.query.letemail}
      this.$api.englishuser.updatesave(userInfo).then((res) => {
          if(res.msg != null) {
            this.$message({
              message: res.msg,
              type: 'error'
            })
          } else {
            Cookies.set('token', res.data.token) // 放置token到Cookie
            sessionStorage.setItem('user', userInfo.account) // 保存用户到本地会话
            this.$store.commit('menuRouteLoaded', false) // 要求重新加载导航菜单
            this.$router.push('/mainpage')  // 提交成功，跳转到主页
          }
        }).catch((res) => {
          this.$message({
          message: res.message,
          type: 'error'
          })
        });
    },
    //加
    // 
  },
 // watch:{'$route:':'getParams'}
}
</script>

<style lang="scss" scoped>
.div-inline{ 
  float:left;
  } 
.login-container {
  -webkit-border-radius: 5px;
  border-radius: 5px;
  -moz-border-radius: 5px;
  background-clip: padding-box;
  position: relative; 
  right:166px;
  width: 392px;
  padding: 0px 0px 0px 0px;
  background: #fff;
  border: 1px solid #eaeaea;
  box-shadow: 0 0 0px #cac6c6;
}


</style>
