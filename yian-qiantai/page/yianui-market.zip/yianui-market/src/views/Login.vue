<template>
    <el-form label-position="left" class="demo-ruleForm login-container">
       <el-form-item>
          <img style="width:131px;height:25px;margin-top:50px;margin-left:20px;"  src="@/assets/logo.png" />   
       </el-form-item>
          <!-- <p style="font-size:20px;margin-left:20px;margin-top:20px;">Sign in</p> -->
        <el-form-item header-align="center" prop="phone" label="Email or Phone" label-width="190px" text-align="center"  style="margin-left:30px;margin-top:50px;">
          <el-input style="width:210px;right:60px;" type="text"   header-align="left" label-width="25px" placeholder="Please enter Email or Phone"  v-model="loginForm.account"></el-input>
       </el-form-item>
       <el-form-item header-align="center" prop="password" label="Password" label-width="190px" text-align="center" style="margin-left:30px;margin-top:50px;">
          <el-input style="width:210px;right:60px;" type="password"  header-align="left" label-width="25px" placeholder="Please enter Password"  v-model="loginForm.password"> </el-input>
       </el-form-item>
       <el-form-item>
          <el-button type="primary" style="width:48%;margin-top:40px;margin-left:30px;background: #854FC1;" @click.native.prevent="login">Sign in</el-button>
       </el-form-item>
         <el-button type="primary" style="width:48%;margin-top:40px;margin-left:30px;" @click.native.prevent="register" >Sign up</el-button>
         <div style="width:300px;height:115px;"></div>
        </el-form>
</template>
<script>
   import { mapState } from 'vuex'
   import Cookies from "js-cookie"
   import ThemePicker from "@/components/ThemePicker"
   import LangSelector from "@/components/LangSelector"

  export default {
    //  name: 'HelloWorld',
     data () {
     return {
        msg: '',
        //checked: false,
      //加
         loginForm: {
          account: '',
          password: ''
      
      }, 
      //加
    }
  },
  methods:{
    //加
      register() { 
    
       //  let userInfo = Object.assign({}, this.loginForm )
      let userInfo = {account:"admin", password:"admin"}
      this.$api.login.login(userInfo).then((res) => {

          if(res.msg != null) {
            this.$message({
                message: res.msg,
                type: 'error'
            })
          } else {
            Cookies.set('token', res.data.token), // 放置token到Cookie
            console.log (res.data.token+"485545959595"),
            sessionStorage.setItem('user', userInfo.account) // 保存用户到本地会话
            this.$router.push('/register')
          }
      
        }).catch((res) => {
          this.$message({
          message: res.message,
          type: 'error'
          })
        });
    
    this.$router.push('/register')  // 注册成功 
    },
     login() { 
        //  let userInfo = Object.assign({}, this.loginForm )
      let userInfo = {account:this.loginForm.account, password:this.loginForm.password}
      this.$api.login.login(userInfo).then((res) => {
          if(res.msg != null) {
            this.$message({
                message: res.msg,
                type: 'error'
            })
          } else {
            Cookies.set('token', res.data.token) // 放置token到Cookie
            sessionStorage.setItem('user', userInfo.account) // 保存用户到本地会话
            this.$router.push('/mainpage')
          }
        console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        }).catch((res) => {
          this.$message({
          message: res.message,
          type: 'error'
          })
        });
    },
  }
}
</script>

<style lang="scss" scoped>
.div-inline{ 
  float:left;
  } 
.login-container {
  -webkit-border-radius: 5px;
  border-radius: 5px;
  -moz-border-radius: 5px;
  background-clip: padding-box;
  position: relative; 
  right:170px;
  width: 395px;
   height:100%;
  padding: 0px 0px 0px 0px;
  background: #fff;
  border: 1px solid #eaeaea;
  box-shadow: 0 0 0px #cac6c6;
}

.cw-1{
position:relative;
margin-left:20px;
margin-top:1%;
font-family: PingFangSC-Regular;
font-size: 30px;
color: #333333;
line-height: 30px;
}
.cw-2{
position:relative;
left:24px;
font-family: PingFangSC-Regular;
font-size: 16px;
color: #333333;
line-height: 20px;
}
.cw-3{
position:relative;
margin-left:47px;
font-family: PingFangSC-Regular;
font-size: 14px;
color: #854FC1;
line-height: 20px;
}

.cw-5{
position:relative;
background: #FEE9C7;
border-radius: 8px;
width:156px;
height:220px;
margin-left:35px;
float:left;
}
.cw-6{
background: #E3E8FE;
border-radius: 8px;
width:156px;
height:220px;
margin-left:35px;
float:left;
}
.cw-7{ 
font-family: PingFangSC-Medium;
font-size: 20px;
color: #643232;
line-height: 20px;
position:relative;
margin-left:38px;
margin-top:16px;
}
.cw-8{
font-family: PingFangSC-Regular;
font-size: 12px;
color: #643232;
line-height: 12px;
position:relative;
margin-left:20px;
margin-top:5px;
}
.cw-9{

opacity: 0.9;
background: #FFFFFF;
border-radius: 16px;
width:124px;
height:32;
margin-bottom:16px;
margin-left:16px;
}
.cw-10{ 
font-family: PingFangSC-Medium;
font-size: 20px;
color: #3849A2;
line-height: 20px;
position:relative;
margin-left:38px;
margin-top:16px;
}
.cw-11{
font-family: PingFangSC-Regular;
font-size: 12px;
color: #3849A2;
line-height: 12px;
position:relative;
margin-left:20px;
margin-top:5px;
}
.cw-12{
opacity: 0.9;
background: #FFFFFF;
border-radius: 16px;
width:124px;
height:32;
margin-bottom:16px;
margin-left:16px;
}
.aaa{
float:left;
}
.bbb{
margin-left:80px;
margin-top:30px;

float:left;
}
.ccc{
float:left;
}
</style>
